﻿namespace Map_Creator
{
    partial class Editor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBoxColor = new System.Windows.Forms.PictureBox();
            this.grpBoxColors = new System.Windows.Forms.GroupBox();
            this.btnCircle = new System.Windows.Forms.Button();
            this.btnNoHookEnemy = new System.Windows.Forms.Button();
            this.btnGate = new System.Windows.Forms.Button();
            this.btnOxy = new System.Windows.Forms.Button();
            this.btnObstacle = new System.Windows.Forms.Button();
            this.btnEnemy = new System.Windows.Forms.Button();
            this.btnBlank = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.grpMap = new System.Windows.Forms.GroupBox();
            this.btnHoriz = new System.Windows.Forms.Button();
            this.btnVert = new System.Windows.Forms.Button();
            this.btnSquare = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxColor)).BeginInit();
            this.grpBoxColors.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // picBoxColor
            // 
            this.picBoxColor.Location = new System.Drawing.Point(6, 19);
            this.picBoxColor.Name = "picBoxColor";
            this.picBoxColor.Size = new System.Drawing.Size(86, 75);
            this.picBoxColor.TabIndex = 0;
            this.picBoxColor.TabStop = false;
            // 
            // grpBoxColors
            // 
            this.grpBoxColors.Controls.Add(this.btnCircle);
            this.grpBoxColors.Controls.Add(this.btnVert);
            this.grpBoxColors.Controls.Add(this.btnSquare);
            this.grpBoxColors.Controls.Add(this.btnHoriz);
            this.grpBoxColors.Controls.Add(this.btnNoHookEnemy);
            this.grpBoxColors.Controls.Add(this.btnGate);
            this.grpBoxColors.Controls.Add(this.btnOxy);
            this.grpBoxColors.Controls.Add(this.btnObstacle);
            this.grpBoxColors.Controls.Add(this.btnEnemy);
            this.grpBoxColors.Controls.Add(this.btnBlank);
            this.grpBoxColors.Location = new System.Drawing.Point(12, 12);
            this.grpBoxColors.Name = "grpBoxColors";
            this.grpBoxColors.Size = new System.Drawing.Size(100, 249);
            this.grpBoxColors.TabIndex = 1;
            this.grpBoxColors.TabStop = false;
            this.grpBoxColors.Text = "Colors";
            // 
            // btnCircle
            // 
            this.btnCircle.BackColor = System.Drawing.Color.Purple;
            this.btnCircle.Location = new System.Drawing.Point(6, 157);
            this.btnCircle.Name = "btnCircle";
            this.btnCircle.Size = new System.Drawing.Size(40, 40);
            this.btnCircle.TabIndex = 6;
            this.btnCircle.UseVisualStyleBackColor = false;
            this.btnCircle.Click += new System.EventHandler(this.colorClick);
            // 
            // btnNoHookEnemy
            // 
            this.btnNoHookEnemy.BackColor = System.Drawing.Color.Yellow;
            this.btnNoHookEnemy.Location = new System.Drawing.Point(52, 65);
            this.btnNoHookEnemy.Name = "btnNoHookEnemy";
            this.btnNoHookEnemy.Size = new System.Drawing.Size(40, 40);
            this.btnNoHookEnemy.TabIndex = 5;
            this.btnNoHookEnemy.UseVisualStyleBackColor = false;
            this.btnNoHookEnemy.Click += new System.EventHandler(this.colorClick);
            // 
            // btnGate
            // 
            this.btnGate.BackColor = System.Drawing.Color.Green;
            this.btnGate.Location = new System.Drawing.Point(52, 203);
            this.btnGate.Name = "btnGate";
            this.btnGate.Size = new System.Drawing.Size(40, 40);
            this.btnGate.TabIndex = 4;
            this.btnGate.UseVisualStyleBackColor = false;
            this.btnGate.Click += new System.EventHandler(this.colorClick);
            // 
            // btnOxy
            // 
            this.btnOxy.BackColor = System.Drawing.Color.Aqua;
            this.btnOxy.Location = new System.Drawing.Point(6, 203);
            this.btnOxy.Name = "btnOxy";
            this.btnOxy.Size = new System.Drawing.Size(40, 40);
            this.btnOxy.TabIndex = 3;
            this.btnOxy.UseVisualStyleBackColor = false;
            this.btnOxy.Click += new System.EventHandler(this.colorClick);
            // 
            // btnObstacle
            // 
            this.btnObstacle.BackColor = System.Drawing.Color.Black;
            this.btnObstacle.Location = new System.Drawing.Point(52, 19);
            this.btnObstacle.Name = "btnObstacle";
            this.btnObstacle.Size = new System.Drawing.Size(40, 40);
            this.btnObstacle.TabIndex = 2;
            this.btnObstacle.UseVisualStyleBackColor = false;
            this.btnObstacle.Click += new System.EventHandler(this.colorClick);
            // 
            // btnEnemy
            // 
            this.btnEnemy.BackColor = System.Drawing.Color.Red;
            this.btnEnemy.Location = new System.Drawing.Point(6, 65);
            this.btnEnemy.Name = "btnEnemy";
            this.btnEnemy.Size = new System.Drawing.Size(40, 40);
            this.btnEnemy.TabIndex = 1;
            this.btnEnemy.UseVisualStyleBackColor = false;
            this.btnEnemy.Click += new System.EventHandler(this.colorClick);
            // 
            // btnBlank
            // 
            this.btnBlank.BackColor = System.Drawing.Color.White;
            this.btnBlank.Location = new System.Drawing.Point(6, 19);
            this.btnBlank.Name = "btnBlank";
            this.btnBlank.Size = new System.Drawing.Size(40, 40);
            this.btnBlank.TabIndex = 0;
            this.btnBlank.UseVisualStyleBackColor = false;
            this.btnBlank.Click += new System.EventHandler(this.colorClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.picBoxColor);
            this.groupBox2.Location = new System.Drawing.Point(12, 288);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(100, 100);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Current Tile";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(12, 408);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 84);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save File";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(12, 498);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(100, 84);
            this.btnLoad.TabIndex = 3;
            this.btnLoad.Text = "Load File";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // grpMap
            // 
            this.grpMap.Location = new System.Drawing.Point(118, 12);
            this.grpMap.Name = "grpMap";
            this.grpMap.Size = new System.Drawing.Size(570, 570);
            this.grpMap.TabIndex = 4;
            this.grpMap.TabStop = false;
            this.grpMap.Text = "Map";
            // 
            // btnHoriz
            // 
            this.btnHoriz.BackColor = System.Drawing.Color.Orange;
            this.btnHoriz.Location = new System.Drawing.Point(6, 111);
            this.btnHoriz.Name = "btnHoriz";
            this.btnHoriz.Size = new System.Drawing.Size(40, 40);
            this.btnHoriz.TabIndex = 7;
            this.btnHoriz.UseVisualStyleBackColor = false;
            this.btnHoriz.Click += new System.EventHandler(this.colorClick);
            // 
            // btnVert
            // 
            this.btnVert.BackColor = System.Drawing.Color.Pink;
            this.btnVert.Location = new System.Drawing.Point(52, 111);
            this.btnVert.Name = "btnVert";
            this.btnVert.Size = new System.Drawing.Size(40, 40);
            this.btnVert.TabIndex = 8;
            this.btnVert.UseVisualStyleBackColor = false;
            this.btnVert.Click += new System.EventHandler(this.colorClick);
            // 
            // btnSquare
            // 
            this.btnSquare.BackColor = System.Drawing.Color.Magenta;
            this.btnSquare.Location = new System.Drawing.Point(52, 157);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(40, 40);
            this.btnSquare.TabIndex = 9;
            this.btnSquare.UseVisualStyleBackColor = false;
            this.btnSquare.Click += new System.EventHandler(this.colorClick);
            // 
            // Editor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(700, 594);
            this.Controls.Add(this.grpMap);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpBoxColors);
            this.Name = "Editor";
            this.Text = "Level Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Editor_FormClosing);
            this.Load += new System.EventHandler(this.Editor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxColor)).EndInit();
            this.grpBoxColors.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxColor;
        private System.Windows.Forms.GroupBox grpBoxColors;
        private System.Windows.Forms.Button btnBlank;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnObstacle;
        private System.Windows.Forms.Button btnEnemy;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.GroupBox grpMap;
        private System.Windows.Forms.Button btnGate;
        private System.Windows.Forms.Button btnOxy;
        private System.Windows.Forms.Button btnNoHookEnemy;
        private System.Windows.Forms.Button btnCircle;
        private System.Windows.Forms.Button btnHoriz;
        private System.Windows.Forms.Button btnVert;
        private System.Windows.Forms.Button btnSquare;
    }
}