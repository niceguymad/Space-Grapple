﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Map_Creator
{
    public partial class frmMain : Form
    {
        // Initializes everything when creating the Main Form
        public frmMain()
        {
            InitializeComponent();
        }

        // Checks to make sure the data put into the width and height are within the boundaries and if so,
        // Creates a new map in the editor
        private void btnCreate_Click(object sender, EventArgs e)
        {
            int width = int.Parse(txtWidth.Text);
            int height = int.Parse(txtHeight.Text);

            Editor newEditor = new Editor(width, height);
            this.Hide();
            newEditor.ShowDialog();
        }

        // Loads the file that the user selects and opens it in the editor
        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog loadFile = new OpenFileDialog();
            loadFile.Title = "Open a level file";
            loadFile.Filter = "Level Files|*.level";
            if (loadFile.ShowDialog() == DialogResult.OK)
            {
                FileStream inStream = File.OpenRead(loadFile.FileName);
                BinaryReader reader = new BinaryReader(inStream);
                Editor newEditor = new Editor(reader.ReadInt32(), reader.ReadInt32());                
                this.Hide();                
                newEditor.LoadMap(loadFile);
                inStream.Dispose();
                MessageBox.Show("File Loaded Successfully");
                newEditor.Text = "Level Editor - " + loadFile.SafeFileName;
                newEditor.ShowDialog();

            }
        }

        // Closes the application when the user presses the X button
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Close();
        }
    }
}
