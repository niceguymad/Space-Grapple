﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Map_Creator
{
    public partial class Editor : Form
    {
        // Boolean to see if there is unsaved data or not
        private bool isSaved = true;

        // Variables used to hold data needed for map
        private int width;
        private int height;
        private int mapWidth;
        private int mapHeight;
        private int pbWidth;
        private int pbHeight;

        // Forced starting locations for the map
        private int xLocation = 5;
        private int yLocation = 9;

        // Size and List for the picture boxes
        private int size;
        List<PictureBox> boxes;

        // Sets all variables once loaded
        public Editor(int width, int height)
        {
            InitializeComponent();

            this.width = width;
            this.height = height;

            mapWidth = grpMap.Size.Width;
            mapHeight = grpMap.Size.Height;

            pbWidth = grpMap.Size.Width / width; // 15 - Hard variable
            pbHeight = grpMap.Size.Height / height; // 15 - Hard variable

            /*
             Unable to perfectly square tiles if disproportionate width and height exist
             An attempt was made but did not work
            if (pbWidth % pbHeight != 0)
            {
                int temp = (pbWidth % pbHeight);
                pbWidth = pbHeight;
                int newSize = grpMap.Size.Width + (temp * pbWidth);
                grpMap.Size = new Size(newSize, pbHeight);
                ActiveForm.Size = new Size(newSize, ActiveForm.Size.Height);
            }
            */

            /*
            // Checks if the projected width is higher than the mapWidth, if so, makes the mapHidth larger
            if ((width * pbWidth) > mapWidth)
            {
                mapWidth += ((width * pbWidth) - mapWidth);
                grpMap.Size = new Size(mapWidth, mapHeight);
            }

            // Checks if the projected height is higher than the mapHeight, if so, makes the mapHeight larger
            if ((height * pbHeight) > mapHeight)
            {
                mapHeight += ((height * pbHeight) - mapHeight);
                grpMap.Size = new Size(mapWidth, mapHeight);
            }
            */

            size = width * height;
            boxes = new List<PictureBox>();
        }

        // Upon loading, draws all of the pictures boxes in the group box
        private void Editor_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < width; i++)
            {
                xLocation = 5 + (i * pbWidth);
                yLocation = 9;
                for (int j = 0; j < height; j++)
                {                    
                    PictureBox box = new PictureBox();
                    boxes.Add(box);
                    box.Size = new Size(pbWidth, pbHeight);
                    box.Location = new Point(xLocation, yLocation);
                    box.BackColor = Color.White;
                    box.MouseDown += new MouseEventHandler(drawColor);
                    //box.MouseEnter += Box_MouseEnter; // Used for mouse dragging, not sure if going to use in level editor or not yet. Difficulty creating
                    box.Capture = false;
                    grpMap.Controls.Add(box);
                    yLocation += pbHeight;
                }
            }
        }

        // Used for mouse dragging, currently not implemented
        /*
        private void Box_MouseEnter(object sender, EventArgs e)
        {
            MouseEventArgs e = new MouseEventArgs();
            if (e.MouseButtons.)
            {
                drawColor(sender, e);
            }
        }
        */

        // Used for the color buttons that will select the color used
        private void colorClick(object sender, EventArgs e)
        {
            picBoxColor.BackColor = ((Button)sender).BackColor;
        }

        // Finds the Current color and draws that onto the picturebox clicked
        private void drawColor(object sender, EventArgs e)
        {
            ((PictureBox)sender).BackColor = picBoxColor.BackColor;
            isSaved = false;
            if(!ActiveForm.Text.Contains("*"))
            {
                ActiveForm.Text += "*";
            }
        }

        // Saves all necessary data to a file
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Title = "Save a level file";
            saveFile.Filter = "Level Files|*.level";
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                SaveMap(saveFile);
            }
            MessageBox.Show("File Saved Successfully");
            ActiveForm.Text = "Level Editor - " + Path.GetFileName(saveFile.FileName);
        }

        // Opens up the Open File Dialog and asks for data, sends that to the LoadMap() Method
        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog loadFile = new OpenFileDialog();
            loadFile.Title = "Open a level file";
            loadFile.Filter = "Level Files|*.level";
            if (loadFile.ShowDialog() == DialogResult.OK)
            {
                // Clears all of the picture boxes in the group box and then loads the new data
                grpMap.Controls.Clear();
                LoadMap(loadFile);
            }
            MessageBox.Show("File Loaded Successfully");
            isSaved = true;
            ActiveForm.Text = "Level Editor - " + loadFile.SafeFileName;
        }

        // Upon closing, bring up the mainForm again
        private void Editor_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Checks if there is unsaved data, if so, asks the user if they are ok with quitting or not
            if (isSaved == false)
            {
                DialogResult result = MessageBox.Show("There are unsaved changes. Are you sure you want to quit?", 
                    "Unsaved Changes", MessageBoxButtons.YesNo);
                // If yes, return to main form
                if (result == DialogResult.Yes)
                {
                    frmMain mainForm = new frmMain();
                    mainForm.Show();
                }
                // If no, cancel the closing of the form
                else if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            else
            {
                frmMain mainForm = new frmMain();
                mainForm.Show();
            }
        }

        // Loads in all of the data
        public void LoadMap(OpenFileDialog loadFile)
        {
            // Clears the List of picture boxes
            boxes.Clear();

            // Creates the necessary FileStream and BinaryReader
            FileStream inStream = File.OpenRead(loadFile.FileName);
            BinaryReader reader = new BinaryReader(inStream);

            // Reads all of the initial data and stores it into its appropriate variables
            width = reader.ReadInt32();
            height = reader.ReadInt32();
            size = reader.ReadInt32();
            mapWidth = reader.ReadInt32();
            mapHeight = reader.ReadInt32();
            pbWidth = reader.ReadInt32();
            pbHeight = reader.ReadInt32();

            // Loops and creates the appropriate picture boxes and settings for them.
            // Reads the data from the saved file for the BackColor and sets that to the appropriate picture box
            for (int i = 0; i < width; i++)
            {
                 xLocation = 5 + (i * pbWidth);
                 yLocation = 9;
                 for (int j = 0; j < height; j++)
                 {                        
                      PictureBox box = new PictureBox();
                      boxes.Add(box);
                      box.Size = new Size(pbWidth, pbHeight);
                      box.Location = new Point(xLocation, yLocation);
                      box.MouseDown += new MouseEventHandler(drawColor);
                      box.BackColor = Color.FromArgb(255, reader.ReadByte(), reader.ReadByte(), reader.ReadByte());
                      grpMap.Controls.Add(box);
                      yLocation += pbHeight;
                 }
            }
            inStream.Dispose();
        }

        // Saves all of the data from the map
        public void SaveMap(SaveFileDialog saveFile)
        {
            // Creates the necessary FileStream and BinaryWriter
            FileStream outStream = File.OpenWrite(saveFile.FileName);
            BinaryWriter output = new BinaryWriter(outStream);

            // Writes all of the necessary data before the picture boxes
            output.Write(width);
            output.Write(height);
            output.Write(size);
            output.Write(mapWidth);
            output.Write(mapHeight);
            output.Write(pbWidth);
            output.Write(pbHeight);

            // Loops through each picture box made and saves its background color
            for (int i = 0; i < size; i++)
            {
                output.Write(boxes[i].BackColor.R);
                output.Write(boxes[i].BackColor.G);
                output.Write(boxes[i].BackColor.B);
            }
            outStream.Dispose();
            isSaved = true;
        }
        
    }
}
