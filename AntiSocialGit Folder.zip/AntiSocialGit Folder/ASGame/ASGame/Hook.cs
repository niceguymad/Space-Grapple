﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Hook
    {
        Texture2D reticle;
        Texture2D rope;
        Texture2D hook;
        Rectangle reticlePosition; // position of the cursor
        Rectangle hookPosition; // position of the grappling hook
        Rectangle clickPosition;
        MouseState mState;
        MouseState mPreviousState;
        Color color;
        Player player;
        bool hookVisible;
        bool hookLimit;
        Point ropeStart;

        Vector2 hookVelocity = new Vector2(0, 0);

        public Hook(Texture2D reticle, Texture2D hook, Texture2D rope, Rectangle reticlePosition, Player player)
        {
            this.reticle = reticle;
            this.hook = hook;
            this.reticlePosition = reticlePosition;
            color = Color.White;
            this.player = player;
            this.rope = rope;
        }

        public Vector2 HookVelocity { get => hookVelocity; set => hookVelocity = value; }

        public void Update(List<Obstacle> platforms, Camera camera)
        {
            mPreviousState = mState;
            mState = Mouse.GetState();
            

            if(mState.LeftButton == ButtonState.Pressed)
            {
                if(mPreviousState.LeftButton != ButtonState.Pressed)
                {
                    hookLimit = false;
                    hookPosition = new Rectangle(player.Position.Location, new Point(25));
                    clickPosition = reticlePosition;
                    hookVelocity = new Vector2(player.Velocity.X / 2 + (float)(10f * (clickPosition.X - player.Position.X) / Math.Sqrt((clickPosition.X - player.Position.X) * (clickPosition.X - player.Position.X) + (clickPosition.Y - player.Position.Y) * (clickPosition.Y - player.Position.Y))), 
                        player.Velocity.Y / 2 + (float)(10f * (clickPosition.Y - player.Position.Y) / Math.Sqrt((clickPosition.X - player.Position.X) * (clickPosition.X - player.Position.X) + (clickPosition.Y - player.Position.Y) * (clickPosition.Y - player.Position.Y))));
                    hookVisible = true;
                }
                color = Color.Navy;

                if(Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y)) >= 350)
                {
                    hookLimit = true;
                }
                if(hookLimit && !hookVelocity.Equals(new Vector2(0,0)))
                {
                    /* Scrapped code that pulls the hook back to the player
                    if (Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y)) >= 20)
                    {
                        hookVelocity = new Vector2((float)(-12f * (hookPosition.X - player.Position.X) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))),
                            (float)(-12f * (hookPosition.Y - player.Position.Y) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))));
                        
                        // attempt to pull hook back in to player regardless of player velocity
                        hookPosition.Location = new Point((int)((player.Position.X + (player.Position.X - hookPosition.X))/30), (int)((player.Position.Y + (player.Position.Y - hookPosition.Y))/30));
                        hookVelocity = new Vector2(0, 0);
                        
                    }*/
                    //else
                    //{
                    hookVisible = false;
                    hookVelocity = new Vector2(0, 0);
                    //}
                }
                foreach (Obstacle platform in platforms)
                {
                    if (!platform.IsOxygen && (!platform.IsEnemy || ((Enemy)platform).Hookable))
                    {
                        float speedMult = .1f; // the multiplier for the velocity of the player when grappling
                        if (platform.IsEnemy && ((Enemy)platform).Moveable)
                        {
                            player.Velocity += new Vector2((float)(speedMult * (hookPosition.X - player.Position.X) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))),
                                (float)(speedMult * (hookPosition.Y - player.Position.Y) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))));
                        }
                        else if (hookPosition.Intersects(platform.Position))
                        {
                            hookVelocity = new Vector2(0, 0);
                            // math below creates a unit vector in the direction of the hooked position from the player and sets the player's velocity to a multiple of that vector
                            player.Velocity += new Vector2((float)(speedMult * (hookPosition.X - player.Position.X) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))),
                                (float)(speedMult * (hookPosition.Y - player.Position.Y) / Math.Sqrt((hookPosition.X - player.Position.X) * (hookPosition.X - player.Position.X) + (hookPosition.Y - player.Position.Y) * (hookPosition.Y - player.Position.Y))));

                            /*if (player.Velocity == new Vector2(0, 0))
                            {
                                player.Velocity = new Vector2((reticlePosistion.X - player.Position.X) / 100, (reticlePosistion.Y - player.Position.Y) / 100);
                            }
                            else
                            {
                                player.Velocity += new Vector2((reticlePosistion.X - player.Position.X) / 150, (reticlePosistion.Y - player.Position.Y) / 150);
                            }*/
                        }
                    }
                    
                }
            }
            else
            {
                color = Color.Red;
                hookVelocity = new Vector2(0, 0);
                hookVisible = false;
                hookLimit = false;
            }
            hookPosition = new Rectangle(hookPosition.X + (int)hookVelocity.X, hookPosition.Y + (int)hookVelocity.Y, hookPosition.Height, hookPosition.Width);
            reticlePosition = new Rectangle(new Point(mState.Position.X - (int)camera.Transform.Translation.X, mState.Position.Y - (int)camera.Transform.Translation.Y), new Point(25, 25));
        }

        public void Draw(SpriteBatch sb)
        {
            if (hookVisible)
            {
                sb.Draw(hook, hookPosition, Color.Black);
                /*below: an attempt to get the hook to rotate so it is always facing away from the player. This works, but it looks worse than the rotation-locked hook, so it has been removed.
                 * sb.Draw(hook, hookPosition.Location.ToVector2(), null, Color.Black,
                    (float)(Math.Atan2(hookPosition.Center.Y - ropeStart.Y, hookPosition.Center.X - ropeStart.X) - Math.PI / 2),
                    hookPosition.Location.ToVector2(), hookPosition.Size, SpriteEffects.None, 0f);*/
                sb.Draw(rope, ropeStart.ToVector2(), null, Color.White,
                (float)Math.Atan2(hookPosition.Center.Y - ropeStart.Y, hookPosition.Center.X - ropeStart.X),
                new Vector2(0f, 0f),
                new Vector2(Vector2.Distance(ropeStart.ToVector2(), hookPosition.Center.ToVector2())/50, .02f),
                SpriteEffects.None, 0f);
            }
            sb.Draw(reticle, reticlePosition, color);
            ropeStart = new Point(player.Position.Center.X, player.Position.Center.Y);
        }
    }
}
