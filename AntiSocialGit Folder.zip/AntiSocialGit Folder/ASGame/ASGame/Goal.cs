﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Goal : Obstacle
    {
        public Goal(Texture2D texture, Rectangle position) : base(texture, position)
        {
            IsGoal = true;
            Active = true;
            Bounce = false;            
        }
    }
}
