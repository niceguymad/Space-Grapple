﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;
using System.Diagnostics;

namespace ASGame
{
    /// <summary>
    /// Jared here ready to code
    /// Rumi here ready to code
    /// Colin did the thing yay
    /// </summary>
    public class Game1 : Game
    {
        //Fields
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Texture2D reticle;
        Texture2D hookTex;
        Texture2D rope;
        Hook hook;
        Button Start;
        Button Resume;
        Button Levels;
        Button NextLevel;
        Button Returnmenu;
        Button Level1;
        Button Level2;
        Button Level3;
        //Button Level4;
        //Button Level5;
        SpriteFont Arial;
        SpriteFont ArialTitle;
        SpriteFont Statefont;
        KeyboardState state;
        Texture2D playerTex;
        Rectangle playerPos = new Rectangle(50, 200, 50, 50);
        Player p1;
        Camera camera;
        Level level;
        Menus menu;
        Texture2D platformTex;
        Texture2D backTex;
        Texture2D backTexGame;
        Texture2D titleTex;
        int levelStage;

        UI GameUI;

        Stopwatch timer;

        // array of all obstacles (despite name, it includes both enemies and platforms)
        List<Obstacle> platforms = new List<Obstacle>();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = GraphicsDevice.DisplayMode.Width;
            graphics.PreferredBackBufferHeight = GraphicsDevice.DisplayMode.Height;
            graphics.IsFullScreen = true;
            graphics.ApplyChanges();
            
            menu = new Menus();            
            //Initializations of buttons
            Start = new Button();
            Resume = new Button();
            Levels = new Button();
            NextLevel = new Button();
            Returnmenu = new Button();
            Level1 = new Button();
            Level2 = new Button();
            Level3 = new Button();
            //Level4 = new Button();
            //Level5 = new Button();
            //Positions of the buttons
            Start.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 , GraphicsDevice.Viewport.Height / 2 + 200, 200, 70);
            NextLevel.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2 , 200, 70);
            Resume.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2, 200, 70);
            Levels.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 , GraphicsDevice.Viewport.Height / 2 + 300, 200, 70);
            Level1.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2- 300, 200, 70);
            Level2.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2 - 200, 200, 70);
            Level3.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2-100, 200, 70);
            //Level4.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2, 200, 70);
            //Level5.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2, 200, 70);
            Returnmenu.rect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 100, GraphicsDevice.Viewport.Height / 2 + 100, 200, 70);
            //Assign the button from the menu class
            menu.startgame = Start;
            menu.resume = Resume;
            menu.levels = Levels;
            menu.nextLevel = NextLevel;  
            menu.returntomenu = Returnmenu;
            menu.level1 = Level1;
            menu.level2 = Level2;
            menu.level3 = Level3;
            //menu.level4 = Level4;
            //menu.level5 = Level5;
            base.Initialize();

        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            // TODO: use this.Content to load your game content here
            playerTex = Content.Load<Texture2D>("PlayerText2");
            p1 = new Player(playerTex, playerPos);
            platformTex = Content.Load<Texture2D>("OrangeBox");
            backTex = Content.Load<Texture2D>("windowTile");
            backTexGame = Content.Load<Texture2D>("backTile");
            level = new Level(this.Content);
            platforms = level.LoadMap(1);
            levelStage = 1;
            reticle = this.Content.Load<Texture2D>("reticle");
            rope = Content.Load<Texture2D>("rope");
            hookTex = Content.Load<Texture2D>("hook");
            hook = new Hook(reticle, hookTex, rope, new Rectangle(), p1);
            GameUI = new UI(Content, GraphicsDevice.Viewport, p1, timer);
            timer = new Stopwatch();
            Start.button =  Content.Load<Texture2D>("Menu/bluebutton");
            Resume.button = Content.Load<Texture2D>("Menu/bluebutton");
            Levels.button = Content.Load<Texture2D>("Menu/bluebutton");
            NextLevel.button = Content.Load<Texture2D>("Menu/bluebutton");
            Returnmenu.button = Content.Load<Texture2D>("Menu/bluebutton");
            Level1.button = Content.Load<Texture2D>("Menu/bluebutton");
            Level2.button = Content.Load<Texture2D>("Menu/bluebutton");
            Level3.button = Content.Load<Texture2D>("Menu/bluebutton");
            //Level4.button = Content.Load<Texture2D>("Menu/bluebutton");
            //Level5.button = Content.Load<Texture2D>("Menu/bluebutton");
            camera = new Camera(GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, level.Width * 50, level.Height * 50);

            Arial = Content.Load<SpriteFont>("Arial");
            ArialTitle = Content.Load<SpriteFont>("ArialTitle");
            titleTex = Content.Load<Texture2D>("Title grpple");
            Statefont = Content.Load<SpriteFont>("Sprites/fancyfont");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();    
            state = Keyboard.GetState();
            switch (menu.state)
            {
                //Clicking on start button moves the state to Game
                case Menustate.Main:                    
                    this.IsMouseVisible = true;
                    p1.dead = false; // New variable, sets the player dead to false                    
                    if (Start.IsClick())
                    {
                        levelStage = 1;
                        menu.state = Menustate.Game;
                    }
                    if (Levels.IsClick())
                    {
                        menu.state = Menustate.Levels;

                    }
                    break;
                //Pressing P pauses the game
                case Menustate.Game:
                    // Temporary bounds variable (should be set from Levels state)
                    Rectangle levelBound = new Rectangle(0, 0, level.Width * 50, level.Height * 50);//(int)(level.MapWidth*3.4), (int)(level.MapHeight*5.9));

                    // Temporary BoundsType variable (should also be set from Levels state)
                    BoundsType boundsType = level.LevelBoundsType;
                    this.IsMouseVisible = false;
                    if(state.IsKeyDown(Keys.P))
                    {
                        menu.state = Menustate.Pause;
                        timer.Stop();
                    }
                    p1.Update(platforms, boundsType, levelBound, timer);

                    // Timer
                    timer.Start();

                    //if (timer.Elapsed.TotalSeconds % 2  == 0)
                    //{
                    //    p1.Oxygen -= 1;
                    //}

                    // New check to see if the player collided with an enemy
                    if (p1.dead == true)
                    {
                        menu.state = Menustate.GameOver;                        
                        Reset(1); // Resets the game
                    }
                    if (p1.Win == true)
                    {
                        levelStage++;
                        p1.Win = false;
                        menu.state = Menustate.Win;
                        Reset(1);
                    }

                    hook.Update(platforms, camera);
                    camera.Update(p1.Position, levelBound);
                    GameUI.Update(camera);
                    foreach(Obstacle o in platforms)
                    {
                        if(o.IsEnemy)
                            ((Enemy)o).Update();
                    }
                    
                    break;
                case Menustate.Win:
                    this.IsMouseVisible = true;
                    if (NextLevel.IsClick())
                    {
                        if (levelStage > 3) // checks if final level completed
                            menu.state = Menustate.Main;
                        else
                        {
                            platforms = level.LoadMap(levelStage);
                            menu.state = Menustate.Game;
                        }
                    }
                    if (Returnmenu.IsClick())
                    {
                        menu.state = Menustate.Main;
                    }
                    break;
                //Level States
                case Menustate.Levels:
                    this.IsMouseVisible = true;
                    if (Level1.IsClick())
                    {
                        
                        menu.state = Menustate.Game;
                        Reset(1);
                    }
                    if (Level2.IsClick())
                    {
                       
                        menu.state = Menustate.Game;
                        Reset(2);
                    }
                    if (Level3.IsClick())
                    {
                        
                        menu.state = Menustate.Game;
                        Reset(3);
                    }
                    if (Returnmenu.IsClick())
                    {
                        menu.state = Menustate.Main;
                    }                 
                    break;
                //Pauses the game and lets you Resume when ready and/or change options
                case Menustate.Pause:
                    this.IsMouseVisible = true;
                    if (Resume.IsClick())
                    {
                        menu.state = Menustate.Game;
                    }
                    if (Returnmenu.IsClick())
                    {
                        menu.state = Menustate.Main;
                    }
                    break;
                case Menustate.GameOver:
                    this.IsMouseVisible = true;
                    if (Returnmenu.IsClick())
                    {
                        menu.state = Menustate.Main;
                    }
                    break;
            }
            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightGray);
            Rectangle background = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            
            switch (menu.state)
            {
                //The main menu state with the title
                case Menustate.Main:
                    spriteBatch.Begin();
                    spriteBatch.Draw(backTex, background, Color.White);
                    menu.Draw(spriteBatch);
                    //Title
                    spriteBatch.Draw(titleTex, new Vector2(350, 0),Color.White);
                    //Button Labels
                    spriteBatch.DrawString(Arial, 
                "Start", new Vector2(Start.rect.X+55, Start.rect.Y+15),
                Color.Black);
                   
                    spriteBatch.DrawString(Arial,
                "Levels", new Vector2(Levels.rect.X + 45, Levels.rect.Y + 10),
                Color.Black);
                    break;         
                    //The game state
                case Menustate.Game:
                    spriteBatch.Begin(transformMatrix: camera.Transform);
                    for(int i = 0; i < 25; i++)
                    {
                        for (int k = 0; k < 25; k++)
                        {
                            spriteBatch.Draw(backTexGame, new Rectangle(215 * k, 130 * i, 215, 130), Color.WhiteSmoke);
                        }
                    }

                    p1.Draw(spriteBatch);                              
                    // Draws the platforms
                    foreach (Obstacle o in platforms)
                    {
                        o.Draw(spriteBatch);
                    }
                    hook.Draw(spriteBatch);
                    GameUI.Draw(spriteBatch);
                    break;
                    //Levels state and buttons
                case Menustate.Levels:
                    spriteBatch.Begin();
                    menu.Draw(spriteBatch);
                    spriteBatch.DrawString(Arial,
                "Level 1", new Vector2(Level1.rect.X + 35, Level1.rect.Y + 10),
                Color.Black);
                    spriteBatch.DrawString(Arial,
                "Level 2", new Vector2(Level2.rect.X + 35, Level2.rect.Y + 10),
                Color.Black);
                    spriteBatch.DrawString(Arial,
                "Level 3", new Vector2(Level3.rect.X + 35, Level3.rect.Y + 10),
                Color.Black);
                    spriteBatch.DrawString(Arial,
                "Return to Menu", new Vector2(Returnmenu.rect.X + 35, Returnmenu.rect.Y + 10),
                Color.Black);

                    break;
                    //The pause state
                case Menustate.Pause:
                    spriteBatch.Begin();
                    menu.Draw(spriteBatch);
                    //Button labels
                   
                    spriteBatch.DrawString(Arial,
               "Resume", new Vector2(Resume.rect.X + 35, Resume.rect.Y + 10),
               Color.Black);
                    spriteBatch.DrawString(Arial,
                "Return to Menu", new Vector2(Returnmenu.rect.X + 35, Returnmenu.rect.Y + 10),
                Color.Black);
                    break;
                case Menustate.Win:
                    spriteBatch.Begin();
                    menu.Draw(spriteBatch);
                    spriteBatch.DrawString(Statefont, "Level Completed!", new Vector2(650, 400),
           Color.Black);
                    //Button labels

                    spriteBatch.DrawString(Arial,
               "Next Level", new Vector2(Resume.rect.X + 35, Resume.rect.Y + 10),
               Color.Black);
                    spriteBatch.DrawString(Arial,
                "Return to Menu", new Vector2(Returnmenu.rect.X + 35, Returnmenu.rect.Y + 10),
                Color.Black);
                    break;
                case Menustate.GameOver:
                    //Death state
                    spriteBatch.Begin();
                    menu.Draw(spriteBatch);
                    spriteBatch.DrawString(Statefont, "Game Over!", new Vector2(750, 400),
                Color.Black); 
                    spriteBatch.DrawString(Arial,
                "Return to Menu", new Vector2(Returnmenu.rect.X + 35, Returnmenu.rect.Y + 10),
                Color.Black);
                    break;
            }

            spriteBatch.End();
            base.Draw(gameTime);
        }

        void Reset(int levelnum)
        {
            p1.Position = new Rectangle(50, 200, 50, 50);
            p1.Velocity = new Vector2(0, 0);
            p1.Acceleration = new Vector2(0, 0);
            p1.Oxygen = 100;
            platforms = level.LoadMap(levelnum);
            timer.Reset();
        }
    }
}
