﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Camera
    {
        // Fields
        Rectangle cameraBounds;
        Vector2 cameraPos;
        Matrix transform;
        Rectangle levelBounds;

        public Camera(int width, int height, int widthLimit, int heightLimit)
        {
            CameraBounds = new Rectangle(0, 0, width, height);
            cameraPos = new Vector2(0, 0);
            levelBounds = new Rectangle(0, 0, widthLimit, heightLimit);
        }

        public Vector2 CameraPos { get { return cameraPos; } }

        public Matrix Transform { get { return transform; } }

        public Rectangle CameraBounds { get => cameraBounds; set => cameraBounds = value; }

        /// <summary>
        /// keeps the player character centered on the screen until an outer bound
        /// of the level is reached, then the camera stops moving in that direction
        /// </summary>
        /// <param name="playerPos">world position of player</param>
        /// <param name="levelBounds">limits of this level (how far the camera can go before stopping)</param>
        public void Update(Rectangle playerPos, Rectangle levelBounds)
        {
            // old code, saved for safety
            /*if (playerPos.X > (cameraBounds.Width/2) && playerPos.X + playerPos.Width + (cameraBounds.Width / 2) < levelBounds.X)
            {
                cameraPos.X = playerPos.X - (cameraBounds.Width / 2);
            }
            if (playerPos.Y > (cameraBounds.Height / 2) && playerPos.Y + +playerPos.Height + (cameraBounds.Height / 2) < levelBounds.Y)
            {
                cameraPos.Y = playerPos.Y - (cameraBounds.Height / 2);
            }*/
            Matrix matPos = Matrix.CreateTranslation(-playerPos.X - (playerPos.Width / 2),
                -playerPos.Y - (playerPos.Height / 2), 
                0);
            Matrix offset = Matrix.CreateTranslation(CameraBounds.Width / 2,
                CameraBounds.Height / 2, 
                0);

            transform = matPos * offset;

            if (CameraBounds != null)
            {
                // Camera bounding (camera will not move past the viewport bounds)
                /*if (transform.M41 < CameraBounds.X)
                {
                    transform.M41 = CameraBounds.X;
                }
                if (transform.M41 > CameraBounds.X + CameraBounds.Width)
                {
                    transform.M41 = CameraBounds.X + CameraBounds.Width;
                }
                if (transform.M42 < CameraBounds.Y)
                {
                    transform.M42 = CameraBounds.Y;
                }
                if(transform.M42 > CameraBounds.Y + CameraBounds.Height)
                {
                    transform.M42 = CameraBounds.Y + CameraBounds.Height;
                }*/
                transform.M41 = -MathHelper.Clamp(-transform.M41, levelBounds.X, levelBounds.X + levelBounds.Width - CameraBounds.Width);
                transform.M42 = -MathHelper.Clamp(-transform.M42, levelBounds.Y, levelBounds.Y + levelBounds.Height - CameraBounds.Height);
            }
        }
    }
}
