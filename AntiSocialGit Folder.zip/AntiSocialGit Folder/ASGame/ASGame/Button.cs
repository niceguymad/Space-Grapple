﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Button
    {
        //Fields
        public Texture2D button;
        public Rectangle rect = new Rectangle(0, 0, 150, 100);

        public bool IsClick()
        {   
            //While the mouse cursor is contained within the rectangle, left click returns as true
            MouseState mouse = Mouse.GetState();
            Point mousePos = new Point(mouse.X, mouse.Y);           
            if(rect.Contains(mousePos))
            {           
                if (mouse.LeftButton == ButtonState.Pressed)
                {
                  return true;
                }          
            }
            return false;
        }
    }
}