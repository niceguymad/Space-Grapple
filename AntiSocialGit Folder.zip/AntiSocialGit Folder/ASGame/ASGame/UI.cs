﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.Diagnostics;

namespace ASGame
{
    class UI
    {
        SpriteFont UI1;
        SpriteFont UI2;
        Vector2 oxygenPos;
        Vector2 percentPos;
        Vector2 timerPos;

        Stopwatch timer;
        Player player;

        public UI(ContentManager content, Viewport viewport, Player player, Stopwatch timer)
        {
            UI1 = content.Load<SpriteFont>("UI");
            UI2 = content.Load<SpriteFont>("UI2");
            oxygenPos = new Vector2(viewport.X + 50, viewport.Y + 50);
            percentPos = new Vector2(viewport.X + 50, viewport.Y + 50);
            this.player = player;
            this.timer = new Stopwatch();
        }

        public void Update(Camera c)
        {
            oxygenPos = new Vector2(-c.Transform.Translation.X + 20 , -c.Transform.Translation.Y + 20);
            percentPos = new Vector2(-c.Transform.Translation.X + 40, -c.Transform.Translation.Y + 60);
            timerPos = new Vector2(-c.Transform.Translation.X + 300, -c.Transform.Translation.Y + 20);
            if(player.dead == true)
            {
                timer.Reset();
            }
            else
            {
                timer.Start();
            }

        }

        public void Draw(SpriteBatch sb)
        {
            sb.DrawString(UI1, "OXYGEN: ", oxygenPos, Color.Black);
            sb.DrawString(UI1, player.Oxygen.ToString("0") + "%", percentPos, Color.Black);
            sb.DrawString(UI1, String.Format("Time: {0:F0}:{1:F2}", timer.Elapsed.Minutes, timer.Elapsed.TotalSeconds % 60), timerPos, Color.Black);
        }
    }
}
