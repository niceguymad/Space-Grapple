﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Obstacle : GameObject
    {
        // Necessary variables
        protected bool isEnemy;
        protected bool isCollectible;
        protected bool isOxygen;
        protected bool active;
        protected bool bounce;
        private bool isGoal;

        // Properties
        public bool IsEnemy { get => isEnemy; set => isEnemy = value; }
        public bool IsCollectible { get => isCollectible; set => isCollectible = value; }
        public bool IsOxygen { get => isOxygen; set => isOxygen = value; }
        public bool Active { get => active; set => active = value; }
        public bool Bounce { get => bounce; set => bounce = value; }
        public bool IsGoal { get => isGoal; set => isGoal = value; }

        // Constructor
        public Obstacle(Texture2D texture, Rectangle position) : base(texture, position)
        {
            IsEnemy = false;
            IsCollectible = false;
            IsOxygen = false;
            Active = true;
            Bounce = true;
            IsGoal = false;
        }

        public override void Update()
        {
            Position = new Rectangle(Position.X + (int)Velocity.X, Position.Y + (int)Velocity.Y, Position.Width, Position.Height);
            base.Update();
        }
        // Draw method
        public override void Draw(SpriteBatch sb)
        {
            if (Active == true)
            {
                base.Draw(sb);
            }
        }

        public void Remove()
        {
            Active = false;
        } 
    }
}
