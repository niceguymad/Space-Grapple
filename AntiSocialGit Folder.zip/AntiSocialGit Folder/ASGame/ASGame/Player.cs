﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace ASGame
{
    class Player : GameObject
    {
        // Basic variables
        Vector2 velocity = new Vector2(0,0);
        Vector2 acceleration = new Vector2(0, 0);
        bool collided = false;
        int oxygen = 100;
        public bool dead = false;
        private bool win;


        // Constructor
        public Player(Texture2D texture, Rectangle position) : base(texture, position)
        {

        }

        // Properties for Velocity and Acceleration
        public Vector2 Velocity { get => velocity; set => velocity = value; }
        public Vector2 Acceleration { get => acceleration; set => acceleration = value; }
        public int Oxygen { get => oxygen; set => oxygen = value; }
        public bool Win { get => win; set => win = value; }

        // Player's Update Method
        public void Update(List<Obstacle> platforms, BoundsType boundsType, Rectangle levelBounds, Stopwatch timer)
        {
             
            Position = new Rectangle(Position.X + (int)velocity.X, Position.Y + (int)velocity.Y, 25, 50);
            Collided(platforms);
            BoundsCollided(boundsType, levelBounds);

            if (timer.Elapsed.TotalSeconds % 2 <= .025)
            {
                Oxygen -= 1;
            }

            if (Oxygen <= 0)
            {
                dead = true;
            }

            Debug.WriteLine(Velocity.X + ", " + Velocity.Y);
            Debug.Write(collided);
        }

        // Player's Draw Method
        public override void Draw(SpriteBatch sb)
        {
            
            base.Draw(sb);
        }

        // Detects collisions with obstacles in the platform list and collectibles in the collectible list, also checks if the ostacle is an enemy, if so, dead becomes true
        public void Collided(List<Obstacle> platforms)
        {

            foreach (Obstacle platform in platforms)
            {
                // checks to see if player collides with any platform
                if (Position.Intersects(platform.Position) && collided == false)
                {

                    // Check if the platform is an enemy
                    if (platform.IsEnemy == true)
                    {
                        Oxygen -= 15;
                    }
                    

                    if (platform.Bounce == false)
                    {
                        if (platform.IsGoal == true)
                        {
                            Win = true;
                        }
                        if (platform.IsCollectible == true)
                        {
                            if (platform.IsOxygen == true)
                            {
                                if (platform.Active == true)
                                {
                                    Oxygen += 20;
                                    platform.Remove();
                                    if (Oxygen > 100)
                                    {
                                        Oxygen = 100;
                                    }
                                }
                            }                            
                        }
                    }
                    

                    if (platform.Bounce)
                    {
                        collided = true;

                        int collideX = (Position.X + Position.Size.X - platform.Position.X);
                        int collideY = (Position.Y + Position.Size.Y - platform.Position.Y);

                        if (collideX >= collideY)
                        {
                            velocity = new Vector2(velocity.X / -2, velocity.Y);

                            if (Position.X < platform.Position.X)
                            {
                                Position = new Rectangle(Position.X - (Position.X + Position.Size.X - platform.Position.X), Position.Y, 25, 50);
                            }
                            else if (platform.Position.X + platform.Position.Size.X > Position.X && Position.Y + Position.Size.Y / 2 < platform.Position.Y)
                            {
                                Position = new Rectangle(Position.X, Position.Y - collideY, 25, 50);
                                velocity = new Vector2(velocity.X * -2, velocity.Y / -2);
                            }
                            else if (platform.Position.X + platform.Position.Size.X > Position.X)
                            {
                                Position = new Rectangle(Position.X + (platform.Position.X + platform.Position.Size.X - Position.X), Position.Y, 25, 50);
                            }
                        }
                        else if (collideX < collideY)
                        {
                            velocity = new Vector2(velocity.X, velocity.Y / -2);
                            if (Position.X < platform.Position.X)
                            {
                                Position = new Rectangle(Position.X - collideX, Position.Y, 25, 50);
                                velocity = new Vector2(velocity.X / -2, velocity.Y * -2);
                            }
                            else if (platform.Position.Y > Position.Y + Position.Size.Y)
                            {
                                Position = new Rectangle(Position.X, Position.Y - (platform.Position.Y - Position.Y - Position.Size.Y), 25, 50);
                            }
                            else if (platform.Position.Y < Position.Y + Position.Size.Y)
                            {
                                Position = new Rectangle(Position.X, Position.Y + (platform.Position.Y - Position.Y + Position.Size.Y), 25, 50);
                            }
                        }
                    }

                    break;
                }         
                else if (collided == true && Position.Intersects(platform.Position) == false)
                {
                    collided = false;
                    break;
                }


            }
        }

        // Checks the collisions with the bounds of the map and handles it accordingly
        private void BoundsCollided(BoundsType boundsType, Rectangle levelBounds)
        {
            switch (boundsType)
            {
                case BoundsType.bounce:
                    if (Position.X + Position.Width > levelBounds.X + levelBounds.Width)
                    {
                        Velocity = new Vector2(Velocity.X * -1, Velocity.Y);
                        Position = new Rectangle(levelBounds.X + levelBounds.Width - Position.Width, Position.Y, Position.Width, Position.Height);
                    }
                    if (Position.X < levelBounds.X)
                    {
                        Velocity = new Vector2(Velocity.X * -1, Velocity.Y);
                        Position = new Rectangle(levelBounds.X, Position.Y, Position.Width, Position.Height);
                    }
                    if (Position.Y + Position.Height > levelBounds.Y + levelBounds.Height)
                    {
                        Velocity = new Vector2(Velocity.X, Velocity.Y * -1);
                        Position = new Rectangle(Position.X, levelBounds.Y + levelBounds.Height - Position.Height, Position.Width, Position.Height);
                    }
                    if(Position.Y < levelBounds.Y)
                    {
                        Velocity = new Vector2(Velocity.X, Velocity.Y * -1);
                        Position = new Rectangle(Position.X, levelBounds.Y, Position.Width, Position.Height);
                    }
                    break;
                case BoundsType.wrap:
                    if (Position.X < levelBounds.X)
                    {
                        Position = new Rectangle(levelBounds.X + levelBounds.Width - Position.Width, Position.Y, Position.Width, Position.Height);
                    }
                    if (Position.X + Position.Width > levelBounds.X + levelBounds.Width)
                    {
                        Position = new Rectangle(levelBounds.X + Position.Width, Position.Y, Position.Width, Position.Height);
                    }
                    if (Position.Y < levelBounds.Y)
                    {
                        Position = new Rectangle(Position.X, levelBounds.Y + levelBounds.Height - Position.Height, Position.Width, Position.Height);
                    }
                    if (Position.Y + Position.Height > levelBounds.Y + levelBounds.Height)
                    {
                        Position = new Rectangle(Position.X, levelBounds.Y + Position.Height, Position.Width, Position.Height);
                    }
                    break;
            }
        }
    }
}
