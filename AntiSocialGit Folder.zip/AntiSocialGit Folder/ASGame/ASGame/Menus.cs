﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    //Enum States
    public enum Menustate
    {
        Main,
        Levels,
        Game,
        Pause,
        Win,
        GameOver
    }
    class Menus
    {
        //Fields
        public Menustate state;
        public Button startgame;
        public Button resume;
        public Button levels;    
        public Button returntomenu;
        public Button level1;
        public Button level2;
        public Button level3;
        //public Button level4;
       // public Button level5;
        public Button nextLevel;

        public Menus()
        {
            state = Menustate.Main;
        }

        //Draw method for the buttons
        public void Draw(SpriteBatch sb)
        {
            switch (state)
            {
                case Menustate.Main:
                    sb.Draw(startgame.button, startgame.rect, Color.White);     
                    sb.Draw(levels.button, levels.rect, Color.White);
                    
                    break;
                case Menustate.Levels:
                    //will includes the buttons for switching to different levels
                    sb.Draw(level1.button, level1.rect, Color.White);
                    sb.Draw(level2.button, level2.rect, Color.White);
                    sb.Draw(level3.button, level3.rect, Color.White);
                    //sb.Draw(level4.button, level4.rect, Color.White);
                    //sb.Draw(level5.button, level5.rect, Color.White);
                    sb.Draw(returntomenu.button, returntomenu.rect, Color.White);


                    break;
                case Menustate.Game:
                    
                   break;
                case Menustate.Win:
                    sb.Draw(returntomenu.button, returntomenu.rect, Color.White);
                    sb.Draw(nextLevel.button, nextLevel.rect, Color.White);
                    break;
                //Pause State
                case Menustate.Pause:
                    sb.Draw(resume.button, resume.rect, Color.White);
                  
                    sb.Draw(returntomenu.button, returntomenu.rect, Color.White);
                    break;
                    //Death State
                case Menustate.GameOver:
                    sb.Draw(returntomenu.button, returntomenu.rect, Color.White);
                    break;
            }
        }
    }
}

