﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class Collectible : Obstacle
    {
        public Collectible(Texture2D texture, Rectangle position) : base(texture, position)
        {
            IsCollectible = true;
            Bounce = false;
        }        
    }
}
