﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace ASGame
{
    enum BoundsType { bounce, kill, wrap };
    class Level
    {
        // Variables used to hold data needed for the level
        private int width;
        private int height;
        private int mapWidth;
        private int mapHeight;
        private int pbWidth;
        private int pbHeight;
        private BoundsType levelBoundsType;

        // Content Manager to load in textures
        ContentManager content;

        // Textures
        Texture2D platformTex;
        Texture2D enemyTex;
        Texture2D oxyTex;
        Texture2D noHookTex;
        Texture2D gateTex;

        // Location for obstacles to be placed
        int xLocation;
        int yLocation;
        int rectangleSize = 50;

        private int size;
        /// <summary>
        /// default constructor, sets level bounds type to "bounce" automatically
        /// </summary>
        /// <param name="content"></param>
        public Level(ContentManager content)
        {
            this.content = content;
            platformTex = content.Load<Texture2D>("OrangeBox");
            enemyTex = content.Load<Texture2D>("ShockBox");
            noHookTex = content.Load<Texture2D>("non hookable");
            oxyTex = content.Load<Texture2D>("Oxygen");
            gateTex = content.Load<Texture2D>("gate");
            levelBoundsType = BoundsType.bounce;
        }
        /// <summary>
        /// parameterized constructor, sets level bounds type to the passed value
        /// </summary>
        /// <param name="content"></param>
        /// <param name="boundsType"></param>
        public Level(ContentManager content, BoundsType boundsType)
        {
            this.content = content;
            platformTex = content.Load<Texture2D>("OrangeBox");
            enemyTex = content.Load<Texture2D>("ShockBox");
            noHookTex = content.Load<Texture2D>("non hookable");
            oxyTex = content.Load<Texture2D>("Oxygen");
            gateTex = content.Load<Texture2D>("gate");
            levelBoundsType = boundsType;
        }

        public BoundsType LevelBoundsType { get { return levelBoundsType; } set { levelBoundsType = value; } }

        public int Width { get => width; set => width = value; }
        public int Height { get => height; set => height = value; }
        public int MapWidth { get => mapWidth; set => mapWidth = value; }
        public int MapHeight { get => mapHeight; set => mapHeight = value; }
        public int PbWidth { get => pbWidth; set => pbWidth = value; }
        public int PbHeight { get => pbHeight; set => pbHeight = value; }

        public List<Obstacle> LoadMap(int levelNum)
        {
            // Creates the necessary FileStream and BinaryReader
            FileStream inStream = File.OpenRead("Content/Levels/level" + levelNum+".level");
            BinaryReader reader = new BinaryReader(inStream);

            // Reads all of the initial data and stores it into its appropriate variables
            width = reader.ReadInt32();
            height = reader.ReadInt32();
            size = reader.ReadInt32();
            mapWidth = reader.ReadInt32();
            mapHeight = reader.ReadInt32();
            pbWidth = reader.ReadInt32();
            pbHeight = reader.ReadInt32();

            List<Obstacle> obstacles = new List<Obstacle>();

            // Loops and creates the appropriate picture boxes and settings for them.
            // Reads the data from the saved file for the BackColor and sets that to the appropriate picture box

            for (int i = 0; i < width; i++)
            {
                // Location for blocks to be placed
                xLocation = 0 + (i * rectangleSize);
                yLocation = 0;
                for (int j = 0; j < height; j++)
                {
                    Color color = new Color(reader.ReadByte(), reader.ReadByte(), reader.ReadByte(), (byte)255);
                    if (color.Equals(Color.Black))
                    {
                        obstacles.Add(new Obstacle(platformTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize)));
                    }
                    else if (color.Equals(Color.Red))
                    {
                        obstacles.Add(new Enemy(enemyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize)));
                    }
                    else if (color.Equals(Color.Yellow))
                    {
                        obstacles.Add(new Enemy(noHookTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize), false, false, false, MovementPattern.square, 0));
                    }
                    /*
                    else if (color.Equals(Color.Orange))
                    {
                        obstacles.Add(new Enemy(enemyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize), true, true, true, MovementPattern.horizontal, 6));
                    }
                    else if (color.Equals(Color.Pink))
                    {
                        obstacles.Add(new Enemy(enemyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize), true, true, true, MovementPattern.vertical, 6));
                    }
                    else if (color.Equals(Color.Purple))
                    {
                        obstacles.Add(new Enemy(enemyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize), true, true, true, MovementPattern.circle, 6));
                    }
                    else if (color.Equals(Color.Magenta))
                    {
                        obstacles.Add(new Enemy(enemyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize), true, true, true, MovementPattern.square, 6));
                    }
                    */
                    else if (color.Equals(Color.Aqua))
                    {
                        obstacles.Add(new OxygenTank(oxyTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize)));
                    }
                    else if (color.Equals(Color.Green))
                    {
                        obstacles.Add(new Goal(gateTex, new Rectangle(xLocation, yLocation, rectangleSize, rectangleSize)));
                    }
                    // Change the yLocation by the size
                    yLocation += rectangleSize;
                }
            }
            inStream.Dispose();
            return obstacles;
        }
        
    }
}
