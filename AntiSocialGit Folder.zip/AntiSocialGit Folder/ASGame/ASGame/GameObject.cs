﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    class GameObject
    {
        Texture2D texture;
        Rectangle position;
        Vector2 velocity;
        public GameObject(Texture2D texture, Rectangle position)
        {
            this.texture = texture;
            this.Position = position;
        }

        public Rectangle Position { get => position; set => position = value; }
        public Vector2 Velocity { get => velocity; set => velocity = value; }
        //public float SizeMultiplier { get => sizeMultiplier; set => sizeMultiplier = value; }

        public virtual void Update()
        {

        }
        public virtual void Draw(SpriteBatch sb)
        {
            sb.Draw(texture, Position, Color.White);
        }
    }
}
