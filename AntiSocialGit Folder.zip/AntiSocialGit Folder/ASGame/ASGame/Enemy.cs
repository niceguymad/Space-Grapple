﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ASGame
{
    enum MovementPattern { vertical, horizontal, circle, square}
    class Enemy : Obstacle
    {
        // Fields
        bool moveable;
        bool hookable;
        bool moving;
        MovementPattern path;
        int pathSize;
        int pathProgress = 0;

        // Constructor
        public Enemy(Texture2D texture, Rectangle position) : base(texture, position)
        {
            IsEnemy = true;
            moveable = false;
            hookable = true;
            moving = false;
        }

        public Enemy(Texture2D texture, Rectangle position, bool moveable, bool hookable, bool moving, MovementPattern mp, int pathSize) : base(texture, position)
        {
            IsEnemy = true;
            this.moveable = moveable;
            this.hookable = hookable;
            this.moving = moving;
            path = mp;
            this.pathSize = pathSize;
        }

        public bool Hookable { get => hookable; set => hookable = value; }
        public bool Moveable { get => moveable; set => moveable = value; }
        public bool Moving { get => moving; set => moving = value; }

        public override void Update()
        {
            if(moving)
            {
                switch(path)
                {
                    case MovementPattern.vertical:
                        if(pathProgress <= pathSize/2)
                        {
                            Velocity = new Vector2(0, 2);
                        }
                        else
                        {
                            Velocity = new Vector2(0, -2);
                        }
                        break;
                    case MovementPattern.horizontal:
                        if (pathProgress <= pathSize / 2)
                        {
                            Velocity = new Vector2(2, 0);
                        }
                        else
                        {
                            Velocity = new Vector2(-2, 0);
                        }
                        break;
                    case MovementPattern.circle:
                        float c = (float)(2 * Math.PI / pathProgress);
                        Velocity = new Vector2((int)(2 * Math.Cos(c)), (int)(2 * Math.Sin(c)));
                        break;
                    case MovementPattern.square:
                        if (pathProgress <= pathSize / 4)
                        {
                            Velocity = new Vector2(0, 2);
                        }
                        if (pathProgress > pathSize / 4 && pathProgress <= pathSize / 2)
                        {
                            Velocity = new Vector2(2, 0);
                        }
                        if (pathProgress > pathSize / 2 && pathProgress <= pathSize * (3 / 4))
                        {
                            Velocity = new Vector2(0, -2);
                        }
                        if (pathProgress > pathSize * (3 / 4))
                        {
                            Velocity = new Vector2(-2, 0);
                        }
                        break;
                }
                if(pathProgress >= pathSize)
                {
                    pathProgress = 0;
                }
                else
                {
                    pathProgress++;
                }
            }
        }

        // Draw Method
        public override void Draw(SpriteBatch sb)
        {
            base.Draw(sb);
        }
    }
}
